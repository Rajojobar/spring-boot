package com.example.MenusEtPlats2025;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MenusEtPlats2025Application {

	public static void main(String[] args) {
		SpringApplication.run(MenusEtPlats2025Application.class, args);
	}

}
