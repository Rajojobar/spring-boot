package com.example.MenusEtPlats2025;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MenusEtPlats2025ApplicationTests {

	@Test
	void contextLoads() {
	}

}
